import{a as b,M as d}from"./messages-BklX8Ul9.js";const n="tentracker-progress-card",P="tentracker-progress-card-style",c="#3F5EB9",H="#4B6BC7",G="#E8EDF8";function O(){try{return b.runtime.getURL("public/brand/logo-trim.png")}catch{return""}}function z(){if(document.getElementById(P))return;const t=document.createElement("style");t.id=P,t.textContent=`
    #${n} {
      display: block;
      width: 100%;
      box-sizing: border-box;
      margin: 0 0 12px;
      font-family: "Roboto", "YouTube Noto", "Arial", sans-serif;
      color: var(--yt-spec-text-primary, #0f0f0f);
    }
    html[dark] #${n},
    [dark] #${n},
    ytd-app[dark] #${n} {
      color: var(--yt-spec-text-primary, #f1f1f1);
    }
    #${n}.tt-hidden { display: none !important; }

    #${n} .tt-card {
      box-sizing: border-box;
      width: 100%;
      padding: 12px;
      border-radius: 14px;
      background: linear-gradient(165deg, ${G} 0%, #ffffff 55%);
      border: 1px solid rgba(63,94,185,0.22);
      box-shadow: 0 8px 24px -16px rgba(63,94,185,0.45);
    }
    html[dark] #${n} .tt-card,
    [dark] #${n} .tt-card,
    ytd-app[dark] #${n} .tt-card {
      background: linear-gradient(165deg, rgba(63,94,185,0.22) 0%, #1f1f1f 60%);
      border-color: rgba(63,94,185,0.35);
      box-shadow: none;
    }

    #${n} .tt-top {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 12px;
    }
    #${n} .tt-brand-wrap { min-width: 0; flex: 1; }
    #${n} .tt-brand {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      line-height: 1;
    }
    #${n} .tt-logo {
      height: 18px;
      width: auto;
      max-width: 120px;
      object-fit: contain;
      display: block;
    }
    html[dark] #${n} .tt-logo,
    [dark] #${n} .tt-logo,
    ytd-app[dark] #${n} .tt-logo {
      /* keep official dark wordmark readable on dark YT */
      filter: invert(1) hue-rotate(180deg) brightness(1.15);
    }
    #${n} .tt-dot {
      width: 6px; height: 6px; border-radius: 50%;
      background: ${c}; flex-shrink: 0;
    }
    #${n}[data-state="done"] .tt-dot { background: #059669; }
    #${n}[data-state="warn"] .tt-dot { background: #d97706; }

    #${n} .tt-pct {
      font-size: 20px; font-weight: 800; line-height: 1;
      font-variant-numeric: tabular-nums; letter-spacing: -0.02em;
      flex-shrink: 0; color: ${c};
    }
    #${n}[data-state="done"] .tt-pct { color: #059669; }
    #${n}[data-state="warn"] .tt-pct { color: #d97706; }

    #${n} .tt-title {
      margin: 8px 0 0; font-size: 14px; font-weight: 600; line-height: 1.35;
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
    }
    #${n} .tt-meta {
      margin: 4px 0 0; font-size: 12px; line-height: 1.4;
      color: var(--yt-spec-text-secondary, #606060);
    }
    #${n} .tt-chips {
      margin-top: 8px; display: flex; flex-wrap: wrap; gap: 6px;
    }
    #${n} .tt-chip {
      font-size: 11px; font-weight: 600; line-height: 1.2;
      padding: 4px 8px; border-radius: 999px;
      background: rgba(63,94,185,0.12);
      color: ${c};
    }
    html[dark] #${n} .tt-chip,
    [dark] #${n} .tt-chip,
    ytd-app[dark] #${n} .tt-chip {
      background: rgba(63,94,185,0.28); color: #c5d0f5;
    }

    #${n} .tt-nudge {
      margin-top: 10px; padding: 8px 10px; border-radius: 10px;
      background: rgba(63,94,185,0.12); font-size: 12px;
    }
    #${n} .tt-nudge-actions { margin-top: 8px; display: flex; gap: 6px; }

    #${n} .tt-bar {
      margin-top: 12px; height: 4px; border-radius: 999px;
      background: rgba(63,94,185,0.15); overflow: hidden;
    }
    #${n} .tt-bar > i {
      display: block; height: 100%; width: 0%; border-radius: inherit;
      background: ${c}; transition: width 0.35s ease;
    }
    #${n}[data-state="done"] .tt-bar > i { background: #059669; }
    #${n}[data-state="warn"] .tt-bar > i { background: #d97706; }

    #${n} .tt-actions {
      margin-top: 12px; display: flex; flex-wrap: wrap; gap: 8px;
    }
    #${n} .tt-btn {
      appearance: none; border: 0; border-radius: 18px;
      padding: 8px 12px; font: inherit; font-size: 12px; font-weight: 600;
      line-height: 1.2; cursor: pointer;
      background: rgba(63,94,185,0.1);
      color: ${c};
    }
    html[dark] #${n} .tt-btn,
    [dark] #${n} .tt-btn,
    ytd-app[dark] #${n} .tt-btn {
      background: rgba(63,94,185,0.22); color: #d5ddf7;
    }
    #${n} .tt-btn.primary {
      background: ${c}; color: #fff;
      box-shadow: 0 8px 18px -10px rgba(63,94,185,0.8);
    }
    html[dark] #${n} .tt-btn.primary,
    [dark] #${n} .tt-btn.primary,
    ytd-app[dark] #${n} .tt-btn.primary {
      background: ${H}; color: #fff;
    }
    #${n} .tt-btn:hover { filter: brightness(1.06); }
  `,(document.head||document.documentElement).appendChild(t)}function K(){return document.querySelector("ytd-watch-flexy #secondary-inner")||document.querySelector("#columns #secondary-inner")||document.querySelector("#secondary-inner")||document.querySelector("ytd-watch-flexy #secondary")||document.querySelector("#secondary")||null}function E(t){const e=K();return e?(t.parentElement===e&&e.firstElementChild===t||(e.firstChild?e.insertBefore(t,e.firstChild):e.appendChild(t)),!0):(t.isConnected||document.documentElement.appendChild(t),!1)}function F(){var e;const t=document.createElement("div");return t.id=n,t.className="tt-hidden",t.innerHTML=`
    <div class="tt-card">
      <div class="tt-top">
        <div class="tt-brand-wrap">
          <div class="tt-brand">
            <img class="tt-logo" data-logo alt="10tracker.com" />
            <span class="tt-dot" aria-hidden="true"></span>
          </div>
          <p class="tt-title" data-title>Watch progress</p>
          <p class="tt-meta" data-meta></p>
          <div class="tt-chips" data-chips></div>
        </div>
        <div class="tt-pct" data-pct>0%</div>
      </div>
      <div class="tt-nudge tt-hidden" data-nudge>
        <div data-nudge-text></div>
        <div class="tt-nudge-actions">
          <button type="button" class="tt-btn primary" data-resume-seek>Continue</button>
          <button type="button" class="tt-btn" data-resume-dismiss>Dismiss</button>
        </div>
      </div>
      <div class="tt-bar" data-bar><i data-fill></i></div>
      <div class="tt-actions">
        <button type="button" class="tt-btn primary" data-open>Open path</button>
        <button type="button" class="tt-btn" data-next>Next</button>
        <button type="button" class="tt-btn" data-complete>Complete</button>
        <button type="button" class="tt-btn" data-skip>Skip</button>
        <button type="button" class="tt-btn" data-pause>Pause sync</button>
        <button type="button" class="tt-btn" data-hide>Hide</button>
      </div>
    </div>
  `,(e=t.querySelector("[data-hide]"))==null||e.addEventListener("click",()=>{t.dataset.userHidden="1",t.classList.add("tt-hidden")}),t}let A=!1,v=null,R=null;function Y(){if(A)return;A=!0,new MutationObserver(()=>{const e=document.getElementById(n);!e||e.classList.contains("tt-hidden")||E(e)}).observe(document.documentElement,{childList:!0,subtree:!0})}function j(){z(),Y();let t=document.getElementById(n);t||(t=F());const e=t.querySelector("[data-logo]"),a=O();return e&&a&&e.getAttribute("src")!==a&&e.setAttribute("src",a),E(t),t}function W(t){const e=(a,o)=>{const i=t.querySelector(a);!i||i.dataset.bound==="1"||(i.dataset.bound="1",i.addEventListener("click",()=>{typeof v=="function"&&v(o,R)}))};e("[data-pause]","pause"),e("[data-complete]","complete"),e("[data-skip]","skip"),e("[data-next]","next"),e("[data-resume-seek]","resume-seek"),e("[data-resume-dismiss]","resume-dismiss")}function J(t){var B,q,M;const e=j();if(R=t,t!=null&&t.onAction&&(v=t.onAction),W(e),!t||t.hide){e.classList.add("tt-hidden");return}if(e.dataset.userHidden==="1"&&t.forceShow!==!0){e.classList.add("tt-hidden");return}t.videoId&&e.dataset.videoId!==t.videoId&&(e.dataset.userHidden="0",e.dataset.videoId=t.videoId),E(e),e.classList.remove("tt-hidden"),e.dataset.state=t.state||"tracking";const a=Math.max(0,Math.min(100,Number(t.percent)||0)),o=e.querySelector("[data-pct]"),i=e.querySelector("[data-title]"),u=e.querySelector("[data-meta]"),I=e.querySelector("[data-chips]"),w=e.querySelector("[data-bar]"),L=e.querySelector("[data-fill]"),m=e.querySelector("[data-open]"),_=e.querySelector("[data-next]"),C=e.querySelector("[data-pause]"),y=e.querySelector("[data-nudge]"),T=e.querySelector("[data-nudge-text]");if(o&&(o.textContent=`${a}%`),i&&(i.textContent=t.title||"Tracked video"),u&&(u.textContent=t.meta||""),L&&(L.style.width=`${a}%`),w&&w.classList.toggle("done",a>=90),I){const p=[];t.sectionLabel&&p.push(t.sectionLabel),t.pathTitle&&p.push(t.pathTitle),(B=t.pathProgress)!=null&&B.total&&p.push(`${t.pathProgress.completed}/${t.pathProgress.total} videos`),(q=t.weekGoal)!=null&&q.weeklyGoal&&p.push(`${t.weekGoal.weeklyCompleted}/${t.weekGoal.weeklyGoal} this week`),I.innerHTML=p.map(U=>`<span class="tt-chip">${String(U).replace(/</g,"")}</span>`).join("")}y&&T&&((M=t.resumeNudge)!=null&&M.percent?(y.classList.remove("tt-hidden"),T.textContent=`Continue at ${t.resumeNudge.percent}%?`):y.classList.add("tt-hidden")),m&&(t.pathUrl?(m.style.display="",m.onclick=()=>window.open(t.pathUrl,"_blank","noopener")):m.style.display="none"),_&&(_.style.display=t.nextVideoId?"":"none"),C&&(C.textContent=t.syncPaused?"Resume sync":"Pause sync")}function f(){const t=document.getElementById(n);t&&t.classList.add("tt-hidden")}const Q=1e4,X=3e4;let $=location.href,x=null,k=!1,h=null,l=!1,V=0;function S(){try{const t=new URL(location.href);return t.hostname.includes("youtube.com")&&!!t.searchParams.get("v")}catch{return!1}}function D(){try{return new URL(location.href).searchParams.get("v")}catch{return null}}function s(t,e={}){return new Promise(a=>{b.runtime.sendMessage({type:t,...e},o=>{if(b.runtime.lastError){a({ok:!1,error:b.runtime.lastError.message});return}a(o||{ok:!1})})})}function Z(t){const e=D();if(!e){f();return}const a=t==null?void 0:t.overlay;if(!a||(t==null?void 0:t.found)===!1||t!=null&&t.catalogMiss){f();return}J({videoId:e,forceShow:e!==h,onAction:tt,...a}),h=e}async function tt(t,e){var o;const a=(e==null?void 0:e.videoId)||D();if(a){if(t==="pause"){await s(d.TOGGLE_PAUSE),r("toggle-pause");return}if(t==="complete"){await s(d.MARK_COMPLETE,{youtubeVideoId:a}),r("complete");return}if(t==="skip"){const u=(await s(d.MARK_SKIP,{youtubeVideoId:a,nextVideoId:e.nextVideoId,percentWatched:e.percent})).nextVideoId||e.nextVideoId;u?location.href=`https://www.youtube.com/watch?v=${u}`:r("skip");return}if(t==="next"&&e.nextVideoId){location.href=`https://www.youtube.com/watch?v=${e.nextVideoId}`;return}if(t==="resume-seek"&&((o=e.resumeNudge)==null?void 0:o.percent)!=null){await s(d.SEEK_PERCENT,{percent:e.resumeNudge.percent}),await s(d.RESUME_NUDGE_DISMISS,{youtubeVideoId:a}),r("resume-seek");return}t==="resume-dismiss"&&(await s(d.RESUME_NUDGE_DISMISS,{youtubeVideoId:a}),r("resume-dismiss"))}}async function r(t="tick"){if(!(!S()||k)){k=!0;try{const e=await s(d.PLAYER_EVENT,{reason:t,event:t});Z(e)}finally{k=!1}}}function N(){x&&clearInterval(x);const t=document.visibilityState==="hidden"?X:Q;x=setInterval(()=>{if(location.href!==$&&($=location.href,h=null,l=!1,f(),g()),!S()){f();return}Date.now()-V>t&&r("interval")},t)}function g(){!S()||l||et()}async function et(){try{if(document.getElementById("tt-player-bridge")){l=!0;return}const t=document.createElement("script");t.id="tt-player-bridge",t.textContent=`
      (function () {
        if (window.__ttPlayerBridge) return;
        window.__ttPlayerBridge = true;
        var last = 0;
        function emit(kind) {
          var now = Date.now();
          if (kind === 'timeupdate' && now - last < 2000) return;
          last = now;
          window.postMessage({ source: 'tt-player', kind: kind }, '*');
        }
        function attach() {
          var videos = Array.prototype.slice.call(document.querySelectorAll('video'));
          if (!videos.length) return false;
          videos.sort(function (a, b) {
            return (b.duration || 0) - (a.duration || 0);
          });
          var v = videos[0];
          if (v.__ttBound) return true;
          v.__ttBound = true;
          ['play', 'pause', 'seeking', 'seeked', 'ended', 'timeupdate'].forEach(function (ev) {
            v.addEventListener(ev, function () { emit(ev); }, { passive: true });
          });
          emit('bound');
          return true;
        }
        var tries = 0;
        var timer = setInterval(function () {
          tries += 1;
          if (attach() || tries > 40) clearInterval(timer);
        }, 500);
        document.addEventListener('yt-navigate-finish', function () {
          tries = 0;
          timer = setInterval(function () {
            tries += 1;
            if (attach() || tries > 40) clearInterval(timer);
          }, 400);
        });
      })();
    `,(document.documentElement||document.head).appendChild(t),l=!0}catch{l=!1}}window.addEventListener("message",t=>{if(t.source!==window)return;const e=t.data;!e||e.source!=="tt-player"||(V=Date.now(),r(e.kind||"player"))});document.addEventListener("visibilitychange",()=>{N(),document.visibilityState==="visible"&&(g(),r("visible"))},{passive:!0});document.addEventListener("yt-navigate-finish",()=>{$=location.href,h=null,l=!1,f(),g(),r("navigate")});N();g();setTimeout(()=>void r("start"),600);setTimeout(()=>void r("start2"),2e3);
